import 'package:jepret/model/Partner.dart';

class Offering {
  double monetaryOffering;
  Partner partner;

  Offering({this.monetaryOffering, this.partner});
}
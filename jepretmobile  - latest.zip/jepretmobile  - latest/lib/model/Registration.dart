class Registration {
  String nik;
  String email;
  String name;
  String phoneNumber;
  String password;

  Registration({this.nik, this.email, this.name, this.phoneNumber, this.password});
}
class Assets {
  static const String LOGO = "assets/img/logo.png";
  static const String ICON_QUEST = "assets/img/quest.png";
  static const String ICON_SURPRISE_BOX = "assets/img/surprise-box.png";
  static const String ICON_PROMOTION = "assets/img/promotion.png";
}